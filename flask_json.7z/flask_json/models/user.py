from __future__ import annotations
from typing import List, Optional
from sqlalchemy import ForeignKey, String, Date, Column, Integer, Time
from sqlalchemy.orm import relationship, Mapped, mapped_column
from base import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    nickname: Mapped[Optional[str]] = mapped_column()
    email: Mapped[Optional[str]] = mapped_column()
    password: Mapped[Optional[str]] = mapped_column()

    def __repr__(self):
        return f"User: {self.nickname}"

    def __str__(self):
        return self.nickname.capitalize()
