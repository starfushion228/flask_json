from __future__ import annotations
from typing import List, Optional
from sqlalchemy import ForeignKey, String, Date, Column, Integer, Time, User
from sqlalchemy.orm import relationship, Mapped, mapped_column

from base import Base


class Event(Base):
    __tablename__ = "events"

    id: Mapped[int] = mapped_column(primary_key=True)
    date = Column("Date", Date)
    time = Column("Time", Time, nullable=True)
    header: Mapped[str] = mapped_column(String(75))
    describe: Mapped[str] = mapped_column(String(250), nullable=True)
    user: Mapped[User] = relationship(back_populates="events")

    def __repr__(self):
        return f"Events: {self.deader}"

    def __str__(self):
        return self.header.capitalize()

