import os
from flask import Flask
from dotenv import load_dotenv
from flask_login import LoginManager
from models.base import Session, create_db

load_dotenv()


app = Flask(__name__)

app.config["SECRET_KEY"] = os.getenv("SECRET_KEY")

login_manager = LoginManager
login_manager.login_view = "login"
login_manager.init_app(app)

create_db()

from models.user import User
from models.base import Session


@login_manager.user_loader
def load_user(user_id: int):
    with Session() as session:
        return session.query(User).where(User.id == user_id).first()


    import routes
